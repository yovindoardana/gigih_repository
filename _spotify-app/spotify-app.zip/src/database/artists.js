const artists = [
  {
    id: 1,
    name: 'artist 1'
  },
  {
    id: 2,
    name: 'artist 2'
  },
  {
    id: 3,
    name: 'artist 3'
  }
];

module.exports = artists;

// CRUD
