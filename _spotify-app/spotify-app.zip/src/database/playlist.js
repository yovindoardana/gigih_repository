const playlist = [];

module.exports = playlist;

// Playlist GET to get a song in the playlist
