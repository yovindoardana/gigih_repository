const songs = [
  {
    id: 1,
    title: 'song 1',
    artists: 'artists 1',
    url: 'url 1'
  },
  {
    id: 2,
    title: 'song 2',
    artists: 'artists 2',
    url: 'url 2'
  },
  {
    id: 3,
    title: 'song 3',
    artists: 'artists 3',
    url: 'url 3'
  }
];

module.exports = songs;

// DELETE, UPDATE
